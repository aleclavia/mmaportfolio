import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# =========================================================
# FPS & DURATION (5 EARTH DAYS COMPRESSED TO 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 sec = 240 frames
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Astronomy Physics Constants
PLUTO_TILT = math.radians(122.5) 
SYSTEM_ROTATION_5Sols = math.radians(281.82) 

# =========================================================
# CREATE PLUTO (CRATERED SURFACE - BASE UNIT 1.0)
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1.0)
pluto = bpy.context.object
pluto.name = "Pluto"
bpy.ops.object.shade_smooth()

disp_tex = bpy.data.textures.new("PlutoTerrainTex", type='CLOUDS')
disp_tex.noise_scale = 0.25
disp_tex.noise_depth = 4

disp_mod = pluto.modifiers.new(name="IcyTerrain", type='DISPLACE')
disp_mod.texture = disp_tex
disp_mod.strength = 0.03
disp_mod.mid_level = 0.5

subsurf = pluto.modifiers.new(name="Subdivide", type='SUBSURF')
subsurf.levels = 2
subsurf.render_levels = 2
pluto.modifiers.move(pluto.modifiers.find("Subdivide"), 0)

# Material Configuration
mat = bpy.data.materials.new(name="PlutoMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

tex = nodes.new(type='ShaderNodeTexImage')
bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
output = nodes.new(type='ShaderNodeOutputMaterial')

try:
    tex.image = bpy.data.images.load("C:/textures/pluto_color.jpg")
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: pluto_color.jpg not found, dropping back to procedural mixture.")
    bsdf.inputs['Base Color'].default_value = (0.70, 0.58, 0.50, 1.0)

bsdf.inputs['Roughness'].default_value = 0.90 
links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
pluto.data.materials.append(mat)


# =========================================================
# LINEAR SYSTEM ANIMATION SETUP (PLUTO SELF-ROTATION)
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

pluto.rotation_mode = 'XYZ'
pluto.rotation_euler = (PLUTO_TILT, 0, 0)
pluto.keyframe_insert(data_path="rotation_euler", frame=1)
pluto.rotation_euler = (PLUTO_TILT, 0, SYSTEM_ROTATION_5Sols)
pluto.keyframe_insert(data_path="rotation_euler", frame=240)


# =========================================================
# CHARON MATERIAL SETUP (CHARON.JPG MAPPED CLEANLY)
# =========================================================
charon_mat = bpy.data.materials.new(name="CharonMaterial")
charon_mat.use_nodes = True
c_nodes = charon_mat.node_tree.nodes
c_links = charon_mat.node_tree.links
c_nodes.clear()

c_tex_coord = c_nodes.new(type='ShaderNodeTexCoord')
c_tex = c_nodes.new(type='ShaderNodeTexImage')
c_bsdf = c_nodes.new(type='ShaderNodeBsdfPrincipled')
c_output = c_nodes.new(type='ShaderNodeOutputMaterial')

try:
    c_tex.image = bpy.data.images.load("C:/textures/charon.jpg")
    c_links.new(c_tex_coord.outputs['Generated'], c_tex.inputs['Vector'])
    c_links.new(c_tex.outputs['Color'], c_bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: charon.jpg texture asset missing, processing solid fallback.")
    c_bsdf.inputs['Base Color'].default_value = (0.65, 0.62, 0.60, 1.0)

c_bsdf.inputs['Roughness'].default_value = 0.65 
c_links.new(c_bsdf.outputs['BSDF'], c_output.inputs['Surface'])


# =========================================================
# GENERATE MOONS (ASTRONOMICALLY PROPORTIONAL RADII)
# =========================================================
pluto_moons = [
    {
        "name": "Charon",   
        "radius": 0.51, "orbit": 1.70, "inc": 0.0, "speed_deg": 281.82,  
        "scale": (1.0, 1.0, 1.0), "deform_strength": 0.0, "is_charon": True,
        "force_start_left": True 
    },
    {
        "name": "Styx",     
        "radius": 0.012, "orbit": 2.35, "inc": 0.8, "speed_deg": 710.0,  
        "scale": (1.5, 0.9, 0.6), "deform_strength": 0.015, "is_charon": False,
        "force_start_left": False
    },
    {
        "name": "Nix",      
        "radius": 0.021, "orbit": 2.70, "inc": 0.1, "speed_deg": 530.0,  
        "scale": (1.6, 1.1, 0.8), "deform_strength": 0.025, "is_charon": False,
        "force_start_left": False
    },
    {
        "name": "Kerberos", 
        "radius": 0.014, "orbit": 3.10, "inc": 0.4, "speed_deg": 410.0,  
        "scale": (1.4, 1.4, 0.7), "deform_strength": 0.018, "is_charon": False,
        "force_start_left": False
    },
    {
        "name": "Hydra",    
        "radius": 0.023, "orbit": 3.55, "inc": 0.2, "speed_deg": 330.0,  
        "scale": (1.5, 1.0, 0.9), "deform_strength": 0.030, "is_charon": False,
        "force_start_left": False
    }
]

for idx, pm in enumerate(pluto_moons):
    # Adjust geometry rings based on scale to preserve rendering speed
    segments = 48 if pm["is_charon"] else 24
    ring_count = 24 if pm["is_charon"] else 12
    
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=ring_count, radius=pm["radius"])
    moon = bpy.context.object
    moon.name = pm["name"]
    bpy.ops.object.shade_smooth()
    
    moon.scale = pm["scale"]
    
    if pm["is_charon"]:
        moon.data.materials.append(charon_mat)
    else:
        minor_mat = bpy.data.materials.new(name=f"{pm['name']}Material")
        minor_mat.use_nodes = True
        mnodes = minor_mat.node_tree.nodes
        mlinks = minor_mat.node_tree.links
        mnodes.clear()
        
        m_bsdf = mnodes.new(type='ShaderNodeBsdfPrincipled')
        m_output = mnodes.new(type='ShaderNodeOutputMaterial')
        m_bsdf.inputs['Base Color'].default_value = (0.55, 0.55, 0.57, 1.0) if pm['name'] == 'Kerberos' or pm['name'] == 'Styx' else (0.78, 0.76, 0.74, 1.0)
        
        # Airless structural fragments completely scatter specular beams
        m_bsdf.inputs['Roughness'].default_value = 1.0
        
        mlinks.new(m_bsdf.outputs['BSDF'], m_output.inputs['Surface'])
        moon.data.materials.append(minor_mat)

    if pm["deform_strength"] > 0:
        rock_tex = bpy.data.textures.new(f"{pm['name']}RockTex", type='VORONOI')
        rock_tex.noise_scale = 0.20
        rock_tex.distance_metric = 'DISTANCE'
        
        disp_mod = moon.modifiers.new(name="AsteroidDeform", type='DISPLACE')
        disp_mod.texture = rock_tex
        disp_mod.strength = pm["deform_strength"]
        disp_mod.mid_level = 0.5
        disp_mod.texture_coords = 'LOCAL'
        
    moon.location = (pm["orbit"], 0.0, 0.0)

    pivot = bpy.data.objects.new(f"{pm['name']}Pivot", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    moon.parent = pivot

    start_angle = 180.0 if pm["force_start_left"] else (idx * 65.0)

    # Keyframe Orbital Path Revolutions
    local_inc = PLUTO_TILT + math.radians(pm["inc"])
    pivot.rotation_mode = 'XYZ'
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle + pm["speed_deg"]))
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    # Keyframe Synchronous Spinning 
    moon.rotation_mode = 'XYZ'
    moon.rotation_euler = (0, 0, 0)
    moon.keyframe_insert(data_path="rotation_euler", frame=1)
    moon.rotation_euler = (0, 0, math.radians(pm["speed_deg"]))
    moon.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp


# =========================================================
# LIGHTING RIG
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(-8.0, -6.0, 7.0))
light = bpy.context.object
light.name = "SunLight"
light.rotation_euler = (math.radians(50), math.radians(25), math.radians(-50))
light.data.energy = 6.5
light.data.color = (1.0, 0.98, 0.95)

bpy.ops.object.light_add(type='SUN', location=(8.0, 6.0, -4.0))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.rotation_euler = (math.radians(-130), math.radians(-25), math.radians(130))
fill_light.data.energy = 0.35
fill_light.data.color = (0.7, 0.85, 1.0)
fill_light.data.use_shadow = False


# =========================================================
# CAMERA (PULLED BACK TO FRAMING EXTRA WIDE SPACE PROPORTIONS)
# =========================================================
bpy.ops.object.camera_add(location=(0, -9.5, 0))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35
camera.data.clip_end = 500
scene.camera = camera

try:
    scene.eevee.use_bloom = True
    scene.eevee.bloom_intensity = 0.15
except AttributeError:
    pass


# =========================================================
# 🌌 STAR BACKGROUND
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.0
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.63
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])


# =========================================================
# TAURUS CONSTELLATION
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location = (4.5, 14, 3.5)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0, 1.77),
    "mid_long_1":     (-0.22, 0.0, 0.46),
    "bend":           (0.0, 0.0, 0.0),
    "tip_left_short": (-2.47, 0.0, 0.72),
    "mid_short_1":    (-0.52, 0.0, 0.08),
    "spine_1":        (0.65, 0.0, -0.40),
    "horn_join":      (1.75, 0.0, -0.67),
    "horn_join2":     (1.97, 0.0, -0.78),
    "horn_tip_1":     (0.59, 0.0, -1.25),
    "horn_tip_2":     (1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long", "mid_long_1"),
    ("mid_long_1", "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1", "bend"),
    ("bend", "spine_1"),
    ("spine_1", "horn_join"),
    ("horn_join", "horn_join2"),
    ("horn_join", "horn_tip_1"),
    ("horn_join2", "horn_tip_2"),
]

star_scale_factor = 0.55

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.09 if star_name == "bend" else 0.06
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a, obj_b = star_objects[star_a], star_objects[star_b]
    loc_a, loc_b = obj_a.location.copy(), obj_b.location.copy()
    midpoint = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    
    bpy.ops.mesh.primitive_cylinder_add(radius=0.012, depth=direction.length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()

# Output Settings
scene.render.filepath = "c:/textures/pluto_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Done! Proportional planetary scale changes applied to the Pluto system.")