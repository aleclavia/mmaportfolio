import bpy
import math
import random
import os

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# SYSTEM ENGINE CONFIGURATION (BLENDER 5.1 TARGETED)
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'
scene.render.use_compositing = False

# TIMELINE: 400 Frames Intro Tour + 1440 Frames (60s) Physics Time-lapse = 1840 Total Frames
scene.frame_start = 1
scene.frame_end = 1840
scene.render.fps = 24
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Physics Framework (5 Full Earth Years scaled over 1440 Playback Frames)
EARTH_REVOLUTION = math.radians(5.0 * 360.0)
EARTH_ROTATION = math.radians(5.0 * 365.25 * 360.0)

# =========================================================
# PROCEDURAL & TEXTURE SURFACE FACTORY
# =========================================================
def create_planet_material(name, base_color, texture_filename=None, emission_strength=0.0, roughness=0.85):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
    output = nodes.new(type='ShaderNodeOutputMaterial')
    
    tex_node = nodes.new(type='ShaderNodeTexImage')
    texture_path = f"C:/textures/{texture_filename}" if texture_filename else None
    
    texture_loaded = False
    if texture_path and os.path.exists(texture_path):
        try:
            tex_node.image = bpy.data.images.load(texture_path)
            texture_loaded = True
        except Exception:
            pass

    if emission_strength > 0.0:
        emission = nodes.new(type='ShaderNodeEmission')
        if texture_loaded:
            links.new(tex_node.outputs['Color'], emission.inputs['Color'])
        else:
            emission.inputs['Color'].default_value = base_color
        emission.inputs['Strength'].default_value = emission_strength
        links.new(emission.outputs['Emission'], output.inputs['Surface'])
    else:
        bsdf.inputs['Roughness'].default_value = roughness
        if texture_loaded:
            links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])
        else:
            bsdf.inputs['Base Color'].default_value = base_color
            
        noise = nodes.new(type='ShaderNodeTexNoise')
        bump = nodes.new(type='ShaderNodeBump')
        noise.inputs['Scale'].default_value = 20.0
        bump.inputs['Strength'].default_value = 0.1
        links.new(noise.outputs['Fac'], bump.inputs['Height'])
        links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
        links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
    return mat

# Radiant emission vector material for clear orbit curve visualization
orbit_mat = bpy.data.materials.new(name="OrbitLine_Mat")
orbit_mat.use_nodes = True
onodes = orbit_mat.node_tree.nodes
onodes.clear()
o_emission = onodes.new(type='ShaderNodeEmission')
o_emission.inputs['Color'].default_value = (0.4, 0.55, 0.7, 1.0)
o_emission.inputs['Strength'].default_value = 2.5
o_output = onodes.new(type='ShaderNodeOutputMaterial')
orbit_mat.node_tree.links.new(o_emission.outputs['Emission'], o_output.inputs['Surface'])

# =========================================================
# CENTRAL SOLAR LIGHT MATRIX (MAXIMUM VISIBILITY ADJUSTMENT)
# =========================================================
# Point light embedded directly in the center of the sun mesh radiating 360 degrees outward
bpy.ops.object.light_add(type='POINT', location=(0.0, 0.0, 0.0))
solar_point = bpy.context.object
solar_point.name = "SolarStarLightCore"
solar_point.data.energy = 15000.0  # Boosted exposure to pierce across heavy orbital distances
solar_point.data.color = (1.0, 0.98, 0.93)
solar_point.data.shadow_soft_size = 0.8

# Amplified global ambient spatial fill light to ensure dark planet faces are completely visible
bpy.ops.object.light_add(type='SUN', location=(0.0, 0.0, 20.0))
ambient_fill = bpy.context.object
ambient_fill.name = "SpaceAmbientFill"
ambient_fill.data.energy = 2.2  # Raised significantly to reveal unlit planetary bodies
ambient_fill.data.use_shadow = False
ambient_fill.data.color = (0.85, 0.9, 1.0) # Crisp, neutral cosmic ambient tint

# =========================================================
# GENERATE THE SYSTEM CELESTIAL BODIES
# =========================================================
planets_data = [
    {"name": "Sun",     "rad": 2.2, "orbit": 0.0,  "color": (1.0, 0.45, 0.02, 1.0), "tex": "sun.jpg",     "rot": 0.05,  "rev": 0.0,    "tilt": 7.25},
    {"name": "Mercury", "rad": 0.3, "orbit": 4.5,  "color": (0.45, 0.45, 0.48, 1.0), "tex": "mercury_color.jpg", "rot": 0.017, "rev": 4.15,   "tilt": 0.03},
    {"name": "Venus",   "rad": 0.5, "orbit": 6.2,  "color": (0.85, 0.65, 0.40, 1.0), "tex": "venus_color.jpg",   "rot": -0.004,"rev": 1.62,   "tilt": 177.3},
    {"name": "Earth",   "rad": 0.55,"orbit": 8.5,  "color": (0.15, 0.35, 0.70, 1.0), "tex": "earth_color.jpg",   "rot": 1.0,   "rev": 1.0,    "tilt": 23.44},
    {"name": "Mars",    "rad": 0.4, "orbit": 10.8, "color": (0.75, 0.25, 0.15, 1.0), "tex": "mars_color.jpg",    "rot": 0.96,  "rev": 0.53,   "tilt": 25.19},
    {"name": "Jupiter", "rad": 1.3, "orbit": 15.0, "color": (0.70, 0.55, 0.45, 1.0), "tex": "jupiter_color.jpg", "rot": 2.42,  "rev": 0.084,  "tilt": 3.13},
    {"name": "Saturn",  "rad": 1.0, "orbit": 19.5, "color": (0.80, 0.70, 0.50, 1.0), "tex": "saturn_color.jpg",  "rot": 2.28,  "rev": 0.034,  "tilt": 26.73},
    {"name": "Uranus",  "rad": 0.7, "orbit": 23.5, "color": (0.55, 0.75, 0.80, 1.0), "tex": "uranus_color.jpg",  "rot": -1.39, "rev": 0.011,  "tilt": 97.77},
    {"name": "Neptune", "rad": 0.68,"orbit": 27.0, "color": (0.25, 0.45, 0.85, 1.0), "tex": "neptune_color.jpg", "rot": 1.49,  "rev": 0.006,  "tilt": 28.32},
    {"name": "Pluto",   "rad": 0.18, "orbit": 30.0, "color": (0.55, 0.48, 0.42, 1.0), "tex": "pluto_color.jpg",   "rot": -0.15, "rev": 0.004,  "tilt": 122.53},
]

system_registry = {}

for p in planets_data:
    # 1. Generate Planet Sphere
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=p["rad"])
    obj = bpy.context.object
    obj.name = p["name"]
    bpy.ops.object.shade_smooth()
    
    is_sun = (p["name"] == "Sun")
    mat = create_planet_material(f"{p['name']}_Mat", p["color"], p["tex"], emission_strength=4.5 if is_sun else 0.0)
    obj.data.materials.append(mat)
    
    # 2. Add Native Curve-based Visual Orbit Ring Lines
    if p["orbit"] > 0:
        bpy.ops.curve.primitive_bezier_circle_add(radius=p["orbit"])
        o_curve = bpy.context.object
        o_curve.name = f"{p['name']}_OrbitLine"
        o_curve.data.dimensions = '3D'
        o_curve.data.fill_mode = 'FULL'
        o_curve.data.bevel_depth = 0.018  # Creates structural width visible to camera layout
        o_curve.data.materials.append(orbit_mat)

    # 3. Create Rigs and Parent Hierarchy
    pivot = bpy.data.objects.new(f"{p['name']}_Pivot", None)
    bpy.context.collection.objects.link(pivot)
    obj.parent = pivot
    
    obj.location = (p["orbit"], 0, 0)
    obj.rotation_mode = 'XYZ'
    obj.rotation_euler = (math.radians(p["tilt"]), 0, 0)
    
    system_registry[p["name"]] = {"body": obj, "pivot": pivot, "orbit": p["orbit"]}
    
    # Write intro static keys
    pivot.rotation_mode = 'XYZ'
    pivot.rotation_euler = (0, 0, 0)
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.keyframe_insert(data_path="rotation_euler", frame=400)
    
    obj.keyframe_insert(data_path="rotation_euler", frame=1)
    obj.keyframe_insert(data_path="rotation_euler", frame=400)
    
    # 5-Year Continuous Timeline Physics Configuration (Frames 400 -> 1840)
    bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
    if p["rev"] != 0.0:
        pivot.rotation_euler = (0, 0, EARTH_REVOLUTION * p["rev"])
        pivot.keyframe_insert(data_path="rotation_euler", frame=1840)
    if p["rot"] != 0.0:
        obj.rotation_euler = (math.radians(p["tilt"]), 0, EARTH_ROTATION * p["rot"])
        obj.keyframe_insert(data_path="rotation_euler", frame=1840)

# =========================================================
# SATURN RING INCORPORATION (WITH SATURNRING.JPG)
# =========================================================
saturn_obj = system_registry["Saturn"]["body"]
bpy.ops.mesh.primitive_circle_add(vertices=128, radius=2.3, fill_type='NGON')
ring = bpy.context.object
ring.name = "Saturn_Rings"
ring.parent = saturn_obj
ring.scale[2] = 0.001  # Ultra thin configuration flat disk
ring_mat = create_planet_material("SaturnRingMat", (0.65, 0.58, 0.48, 1.0), "saturnRing.png", roughness=0.5)
ring.data.materials.append(ring_mat)

# =========================================================
# CLOSE-PROXIMITY LUNAR & SATELLITE NETWORK (EARTH EXCLUSIVE)
# =========================================================
earth_obj = system_registry["Earth"]["body"]

satellites_config = [
    {"name": "Moon",       "rad": 0.11, "dist": 0.85, "color": (0.6, 0.6, 0.6, 1.0), "tex": "moon.jpg", "rev": 13.37 * 5, "tilt": 5.14}, 
    {"name": "ISS_Proxy",  "rad": 0.025,"dist": 0.58, "color": (0.9, 0.9, 0.9, 1.0), "tex": None,       "rev": 280.0,    "tilt": 51.64},
    {"name": "SatCom_1",   "rad": 0.018,"dist": 0.70, "color": (0.2, 0.6, 1.0, 1.0), "tex": None,       "rev": 210.0,    "tilt": -35.0}
]

for sat in satellites_config:
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=sat["rad"])
    s_obj = bpy.context.object
    s_obj.name = f"Earth_{sat['name']}"
    bpy.ops.object.shade_smooth()
    s_obj.data.materials.append(create_planet_material(f"{sat['name']}_Mat", sat["color"], sat["tex"]))
    
    # Internal track visualizer loop for satellites
    bpy.ops.curve.primitive_bezier_circle_add(radius=sat["dist"])
    sat_o_curve = bpy.context.object
    sat_o_curve.name = f"{sat['name']}_OrbitLine"
    sat_o_curve.parent = earth_obj
    sat_o_curve.rotation_euler = (math.radians(sat["tilt"]), 0, 0)
    sat_o_curve.data.dimensions = '3D'
    sat_o_curve.data.fill_mode = 'FULL'
    sat_o_curve.data.bevel_depth = 0.005
    sat_o_curve.data.materials.append(orbit_mat)

    s_pivot = bpy.data.objects.new(f"{sat['name']}_Pivot", None)
    bpy.context.collection.objects.link(s_pivot)
    s_pivot.parent = earth_obj
    s_pivot.rotation_euler = (math.radians(sat["tilt"]), 0, 0)
    
    s_obj.parent = s_pivot
    s_obj.location = (sat["dist"], 0, 0)
    
    # Dynamic satellite translation timeline execution keys
    s_pivot.rotation_mode = 'XYZ'
    s_pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    s_pivot.keyframe_insert(data_path="rotation_euler", frame=400)
    
    bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
    s_pivot.rotation_euler = (math.radians(sat["tilt"]), 0, EARTH_ROTATION * (sat["rev"] / (365.25 * 5)))
    s_pivot.keyframe_insert(data_path="rotation_euler", frame=1840)

# =========================================================
# ASTEROID BELTS
# =========================================================
def generate_asteroid_field(name, count, min_r, max_r, size_min, size_max, seed_val):
    random.seed(seed_val)
    ast_mat = create_planet_material(f"{name}_Mat", (0.35, 0.32, 0.30, 1.0))
    anchor = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(anchor)
    
    for i in range(count):
        radius = random.uniform(size_min, size_max)
        bpy.ops.mesh.primitive_uv_sphere_add(segments=8, ring_count=6, radius=radius)
        rock = bpy.context.object
        rock.data.materials.append(ast_mat)
        
        ang = random.uniform(0, math.pi * 2)
        dist = random.uniform(min_r, max_r)
        rock.location = (math.cos(ang) * dist, math.sin(ang) * dist, random.uniform(-0.1, 0.1))
        rock.parent = anchor
        
    anchor.rotation_mode = 'XYZ'
    anchor.keyframe_insert(data_path="rotation_euler", frame=1)
    anchor.keyframe_insert(data_path="rotation_euler", frame=400)
    
    bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
    anchor.rotation_euler = (0, 0, math.radians(120))
    anchor.keyframe_insert(data_path="rotation_euler", frame=1840)

generate_asteroid_field("InnerAsteroidBelt", count=500, min_r=11.5, max_r=13.5, size_min=0.03, size_max=0.06, seed_val=42)
generate_asteroid_field("OuterKuiperBelt", count=500, min_r=31.5, max_r=33.8, size_min=0.04, size_max=0.08, seed_val=24)

# =========================================================
# METEOR PASSING EVENTS
# =========================================================
meteor_mat = create_planet_material("MeteorMat", (1.0, 0.8, 0.5, 1.0), emission_strength=12.0)

for m_id in range(4):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=8, ring_count=4, radius=0.05)
    meteor = bpy.context.object
    meteor.name = f"Meteor_{m_id}"
    meteor.data.materials.append(meteor_mat)
    
    meteor.location = (-100, -100, -10)
    meteor.keyframe_insert(data_path="location", frame=1)
    
    start_f = 450 + (m_id * 320)
    end_f = start_f + 16 
    
    meteor.location = (-20.0 + (m_id * 4.0), -30.0, 12.0 - (m_id * 2.0))
    meteor.keyframe_insert(data_path="location", frame=start_f)
    meteor.location = (30.0 - (m_id * 2.0), 40.0, -10.0)
    meteor.keyframe_insert(data_path="location", frame=end_f)

# =========================================================
# SYSTEM CAMERA CINEMATIC TOUR TIMELINE (FRAMES 1 -> 1840)
# =========================================================
bpy.ops.object.camera_add()
camera = bpy.context.object
camera.name = "CinematicCamera"
camera.data.lens = 26
camera.data.clip_end = 2000
scene.camera = camera
camera.rotation_mode = 'XYZ'

inspection_tour = [
    {"target": "Sun",     "loc": (0.0, -6.5, 2.0),    "rot": (68, 0, 0),    "frame": 1},
    {"target": "Mercury", "loc": (4.5, -1.2, 0.4),    "rot": (72, 0, 75),   "frame": 40},
    {"target": "Venus",   "loc": (6.2, -1.5, 0.5),    "rot": (74, 0, 70),   "frame": 80},
    {"target": "Earth",   "loc": (8.5, -1.6, 0.6),    "rot": (76, 0, 68),   "frame": 120},
    {"target": "Mars",    "loc": (10.8, -1.4, 0.4),   "rot": (76, 0, 75),   "frame": 160},
    {"target": "Jupiter", "loc": (15.0, -4.2, 1.8),   "rot": (70, 0, 65),   "frame": 200},
    {"target": "Saturn",  "loc": (19.5, -3.8, 1.6),   "rot": (71, 0, 68),   "frame": 240},
    {"target": "Uranus",  "loc": (23.5, -2.6, 1.1),   "rot": (74, 0, 75),   "frame": 280},
    {"target": "Neptune", "loc": (27.0, -2.4, 1.0),   "rot": (75, 0, 76),   "frame": 320},
    {"target": "Pluto",   "loc": (33.0, -0.9, 0.3),   "rot": (78, 0, 80),   "frame": 360},
    {"target": "System",  "loc": (0.0, -50.0, 35.0),  "rot": (50, 0, 0),    "frame": 400}
]

bpy.context.preferences.edit.keyframe_new_interpolation_type = 'BEZIER'
for checkpoint in inspection_tour:
    camera.location = checkpoint["loc"]
    camera.rotation_euler = (math.radians(checkpoint["rot"][0]), math.radians(checkpoint["rot"][1]), math.radians(checkpoint["rot"][2]))
    camera.keyframe_insert(data_path="location", frame=checkpoint["frame"])
    camera.keyframe_insert(data_path="rotation_euler", frame=checkpoint["frame"])

bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
camera.keyframe_insert(data_path="location", frame=1840)
camera.keyframe_insert(data_path="rotation_euler", frame=1840)

# =========================================================
# COSMIC WORLD ENVIRONMENT LIGHTING SETUP
# =========================================================
world = scene.world
world.use_nodes = True
wnodes = world.node_tree.nodes
wnodes.clear()

w_bg = wnodes.new(type='ShaderNodeBackground')
w_out = wnodes.new(type='ShaderNodeOutputWorld')
w_noise = wnodes.new(type='ShaderNodeTexNoise')
w_ramp = wnodes.new(type='ShaderNodeValToRGB')
w_mult = wnodes.new(type='ShaderNodeMath')

w_noise.inputs['Scale'].default_value = 600.0
w_noise.inputs['Detail'].default_value = 15.0
w_noise.inputs['Roughness'].default_value = 0.95

w_ramp.color_ramp.interpolation = 'CONSTANT'
w_ramp.color_ramp.elements[0].position = 0.66
w_ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
w_ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

w_mult.operation = 'MULTIPLY'
w_mult.inputs[1].default_value = 10.0

world.node_tree.links.new(w_noise.outputs['Fac'], w_ramp.inputs['Fac'])
world.node_tree.links.new(w_ramp.outputs['Color'], w_mult.inputs[0])
world.node_tree.links.new(w_mult.outputs['Value'], w_bg.inputs['Color'])
world.node_tree.links.new(w_bg.outputs['Background'], w_out.inputs['Surface'])

# =========================================================
# RENDER OUTPUT PIPELINE
# =========================================================
scene.render.filepath = "c:/textures/solar_system_5year_simulation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Success! Central star lighting and robust curve orbits are active.")