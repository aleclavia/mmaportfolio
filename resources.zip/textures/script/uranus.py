import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE CONFIGURATION (BLENDER 5.1 SPECIFIC)
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# =========================================================
# TIMELINE CONFIGURATION (5 EARTH DAYS TIME-LAPSE - 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 seconds
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Astronomy Physics Constants
URANUS_TILT = math.radians(97.77)
SYSTEM_ROTATION_5_DAYS = math.radians(1058.0) 

# =========================================================
# CREATE URANUS (BASE UNIT 1.0)
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1.0)
uranus = bpy.context.object
uranus.name = "Uranus"
bpy.ops.object.shade_smooth()

disp_tex = bpy.data.textures.new("UranusGasTex", type='CLOUDS')
disp_tex.noise_scale = 0.6

disp_mod = uranus.modifiers.new(name="GasLayers", type='DISPLACE')
disp_mod.texture = disp_tex
disp_mod.strength = 0.008   
disp_mod.mid_level = 0.5

subsurf = uranus.modifiers.new(name="Subdivide", type='SUBSURF')
subsurf.levels = 2
subsurf.render_levels = 2
uranus.modifiers.move(uranus.modifiers.find("Subdivide"), 0)

# Material Configuration
mat = bpy.data.materials.new(name="UranusMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

tex = nodes.new(type='ShaderNodeTexImage')
bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
output = nodes.new(type='ShaderNodeOutputMaterial')

try:
    tex.image = bpy.data.images.load("C:/textures/uranus_color.jpg")
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: uranus_color.jpg not found, using pale cyan fallback.")
    bsdf.inputs['Base Color'].default_value = (0.55, 0.85, 0.85, 1.0)

bsdf.inputs['Roughness'].default_value = 0.65  
links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
uranus.data.materials.append(mat)

# =========================================================
# SYSTEM ANIMATION INITIALIZATION
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

uranus.rotation_mode = 'XYZ'
uranus.rotation_euler = (URANUS_TILT, 0, 0)
uranus.keyframe_insert(data_path="rotation_euler", frame=1)
uranus.rotation_euler = (URANUS_TILT, 0, SYSTEM_ROTATION_5_DAYS)
uranus.keyframe_insert(data_path="rotation_euler", frame=240)


# =========================================================
# MOON MATERIAL BUILDER
# =========================================================
def create_custom_moon_mat(name, fallback_color, roughness_val, emission_boost=0.0):
    m_mat = bpy.data.materials.new(name=name)
    m_mat.use_nodes = True
    mnodes = m_mat.node_tree.nodes
    mlinks = m_mat.node_tree.links
    mnodes.clear()

    m_tex_coord = mnodes.new(type='ShaderNodeTexCoord')
    m_tex = mnodes.new(type='ShaderNodeTexImage')
    m_bsdf = mnodes.new(type='ShaderNodeBsdfPrincipled')
    m_output = mnodes.new(type='ShaderNodeOutputMaterial')

    try:
        m_tex.image = bpy.data.images.load("C:/textures/moon.jpg")
        mlinks.new(m_tex_coord.outputs['Generated'], m_tex.inputs['Vector'])
        mlinks.new(m_tex.outputs['Color'], m_bsdf.inputs['Base Color'])
    except RuntimeError:
        m_bsdf.inputs['Base Color'].default_value = fallback_color

    m_bsdf.inputs['Roughness'].default_value = roughness_val
    m_bsdf.inputs['Specular IOR Level'].default_value = 0.05
    
    if emission_boost > 0.0:
        m_bsdf.inputs['Emission Color'].default_value = fallback_color[:3] + (1.0,)
        m_bsdf.inputs['Emission Strength'].default_value = emission_boost

    mlinks.new(m_bsdf.outputs['BSDF'], m_output.inputs['Surface'])
    return m_mat


# =========================================================
# GENERATE PRIMARY MOONS (INCREASED SCALE MULTIPLIER TO 5.5X)
# =========================================================
MOON_SCALE_FACTOR = 5.5

major_moons = [
    {
        "name": "Miranda", 
        "radius": 0.007 * MOON_SCALE_FACTOR, "orbit": 1.40, "inc": 4.4, "speed_deg": 680,  
        "color": (0.65, 0.60, 0.55, 1.0), "roughness": 0.85, "scale": (1.2, 1.1, 0.95), "eb": 0.1
    },
    {
        "name": "Ariel",   
        "radius": 0.012 * MOON_SCALE_FACTOR, "orbit": 1.80, "inc": 0.0, "speed_deg": 520,  
        "color": (0.75, 0.85, 0.90, 1.0), "roughness": 0.40, "scale": (1.0, 1.0, 1.0), "eb": 0.0
    },
    {
        "name": "Umbriel", 
        "radius": 0.012 * MOON_SCALE_FACTOR, "orbit": 2.20, "inc": 0.1, "speed_deg": 360,  
        "color": (0.28, 0.28, 0.30, 1.0), "roughness": 0.98, "scale": (1.0, 1.0, 1.0), "eb": 0.0
    },
    {
        "name": "Titania", 
        "radius": 0.018 * MOON_SCALE_FACTOR, "orbit": 2.70, "inc": 0.1, "speed_deg": 240,  
        "color": (0.82, 0.80, 0.78, 1.0), "roughness": 0.60, "scale": (1.0, 1.0, 1.0), "eb": 0.0
    },
    {
        "name": "Oberon",  
        "radius": 0.017 * MOON_SCALE_FACTOR, "orbit": 3.20, "inc": 0.1, "speed_deg": 160,  
        "color": (0.68, 0.58, 0.55, 1.0), "roughness": 0.90, "scale": (1.0, 1.0, 1.0), "eb": 0.0
    }
]

for idx, mm in enumerate(major_moons):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, radius=mm["radius"])
    moon = bpy.context.object
    moon.name = mm["name"]
    bpy.ops.object.shade_smooth()
    
    moon.scale = mm["scale"]
    moon.data.materials.append(create_custom_moon_mat(f"{mm['name']}Mat", mm["color"], mm["roughness"], mm["eb"]))
    moon.location = (mm["orbit"], 0.0, 0.0)

    pivot = bpy.data.objects.new(f"{mm['name']}Pivot", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    moon.parent = pivot

    start_angle = idx * 72.0
    local_inc = URANUS_TILT + math.radians(mm["inc"])
    
    pivot.rotation_mode = 'ZXY'
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle + mm["speed_deg"]))
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    moon.rotation_mode = 'XYZ'
    moon.rotation_euler = (0, 0, 0)
    moon.keyframe_insert(data_path="rotation_euler", frame=1)
    moon.rotation_euler = (0, 0, math.radians(mm["speed_deg"]))
    moon.keyframe_insert(data_path="rotation_euler", frame=240)


# =========================================================
# GENERATE MINOR MOONS (PROPORTIONALLY BUMPED TO 4.5X TO MATCH)
# =========================================================
random.seed(42)
for i in range(1, 25):
    if i <= 13:
        radius = random.uniform(0.0015, 0.0038) * 4.5
        orbit = random.uniform(1.12, 1.35)
        inc = random.uniform(-2.0, 2.0)
        speed = random.uniform(800, 1300)
        shape_scale = (random.uniform(1.2, 1.5), random.uniform(1.0, 1.2), random.uniform(0.7, 0.9))
    else:
        radius = random.uniform(0.0012, 0.0030) * 4.5
        orbit = random.uniform(3.80, 5.20)
        
        is_retrograde = random.choice([True, True, True, False])
        if is_retrograde:
            inc = random.uniform(42.2, 62.2) 
            speed = random.uniform(-60, -150)
        else:
            inc = random.uniform(-47.8, -37.8)
            speed = random.uniform(60, 120)
        shape_scale = (random.uniform(1.1, 1.3), random.uniform(1.0, 1.1), random.uniform(0.8, 1.0))

    gray_tone = random.uniform(0.38, 0.60)
    color = (gray_tone, gray_tone, gray_tone, 1.0)

    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=radius)
    moon = bpy.context.object
    moon.name = f"MinorMoon_{i}"
    bpy.ops.object.shade_smooth()
    
    moon.scale = shape_scale
    moon.data.materials.append(create_custom_moon_mat(f"{moon.name}Mat", color, 0.9, emission_boost=0.3))
    moon.location = (orbit, 0.0, 0.0)

    pivot = bpy.data.objects.new(f"{moon.name}Pivot", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    moon.parent = pivot

    start_angle = random.uniform(0.0, 360.0)
    local_inc = URANUS_TILT + math.radians(inc)
    
    pivot.rotation_mode = 'ZXY'
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle + speed))
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    moon.rotation_mode = 'XYZ'
    moon.rotation_euler = (0, 0, 0)
    moon.keyframe_insert(data_path="rotation_euler", frame=1)
    moon.rotation_euler = (0, 0, math.radians(speed))
    moon.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp


# =========================================================
# LIGHTING RIG
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(-8.0, -6.0, 7.0))
light = bpy.context.object
light.name = "SunLight"
light.rotation_euler = (math.radians(50), math.radians(25), math.radians(-50))
light.data.energy = 6.5
light.data.color = (1.0, 0.98, 0.95)

bpy.ops.object.light_add(type='SUN', location=(8.0, 6.0, -4.0))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.rotation_euler = (math.radians(-130), math.radians(-25), math.radians(130))
fill_light.data.energy = 0.35
fill_light.data.color = (0.7, 0.85, 1.0)
fill_light.data.use_shadow = False


# =========================================================
# CAMERA (STABILIZED FRAMING)
# =========================================================
bpy.ops.object.camera_add(location=(0, -16.0, 0))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35
camera.data.clip_end = 500
scene.camera = camera


# =========================================================
# 🌌 WORLD ENVIRONMENT (STARFIELD COORD SEED)
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.0
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.63
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])


# =========================================================
# TAURUS CONSTELLATION BACKDROP
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location = (4.5, 14, 3.5)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0, 1.77),
    "mid_long_1":     (-0.22, 0.0, 0.46),
    "bend":           (0.0, 0.0, 0.0),
    "tip_left_short": (-2.47, 0.0, 0.72),
    "mid_short_1":    (-0.52, 0.0, 0.08),
    "spine_1":        (0.65, 0.0, -0.40),
    "horn_join":      (1.75, 0.0, -0.67),
    "horn_join2":     (1.97, 0.0, -0.78),
    "horn_tip_1":     (0.59, 0.0, -1.25),
    "horn_tip_2":     (1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long", "mid_long_1"),
    ("mid_long_1", "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1", "bend"),
    ("bend", "spine_1"),
    ("spine_1", "horn_join"),
    ("horn_join", "horn_join2"),
    ("horn_join", "horn_tip_1"),
    ("horn_join2", "horn_tip_2"),
]

star_scale_factor = 0.55

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.09 if star_name == "bend" else 0.06
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a, obj_b = star_objects[star_a], star_objects[star_b]
    loc_a, loc_b = obj_a.location.copy(), obj_b.location.copy()
    midpoint = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    
    bpy.ops.mesh.primitive_cylinder_add(radius=0.012, depth=direction.length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()


# Output File Configurations
scene.render.filepath = "c:/textures/uranus_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Success! Script running cleanly under modern Blender 5.1 specifications.")