import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# =========================================================
# FPS & DURATION (5 EARTH DAYS EXPANDED TO 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 sec = 240 frames
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Astronomy Consts
JUPITER_TILT = math.radians(3.13) # Real-world axial tilt

# =========================================================
# CREATE JUPITER (WITH LOCAL AXIAL TILT)
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1)
jupiter = bpy.context.object
jupiter.name = "Jupiter"
bpy.ops.object.shade_smooth()

# Subtle atmospheric variation
disp_tex = bpy.data.textures.new("JupiterAtmosphereTex", type='CLOUDS')
disp_tex.noise_scale = 0.4
disp_tex.noise_depth = 2

disp_mod = jupiter.modifiers.new(name="AtmosphereSurface", type='DISPLACE')
disp_mod.texture = disp_tex
disp_mod.strength = 0.01 
disp_mod.mid_level = 0.5

# Jupiter Material
mat = bpy.data.materials.new(name="JupiterMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

tex = nodes.new(type='ShaderNodeTexImage')
bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
output = nodes.new(type='ShaderNodeOutputMaterial')

try:
    tex.image = bpy.data.images.load("C:/textures/jupiter_color.jpg") 
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: jupiter_color.jpg not found, using fallback color instead.")
    bsdf.inputs['Base Color'].default_value = (0.75, 0.58, 0.47, 1.0) 

bsdf.inputs['Roughness'].default_value = 0.4
links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
jupiter.data.materials.append(mat)


# =========================================================
# ACCURATE MOON CREATION HELPER
# =========================================================
def create_accurate_moon(name, radius, orbit_radius, inclination_deg, total_rotation_deg, color, start_angle_deg, is_spherical=True):
    if is_spherical:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=radius)
        moon = bpy.context.object
    else:
        # Minor moons are non-spherical irregular asteroid shapes
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=radius)
        moon = bpy.context.object
        # Randomly distort dimensions to make it look non-spherical / oblong
        moon.scale = (random.uniform(0.7, 1.3), random.uniform(0.7, 1.3), random.uniform(0.7, 1.3))
        bpy.ops.object.transform_apply(scale=True, rotation=False, location=False)

    moon.name = name
    bpy.ops.object.shade_smooth()
    
    # Position along local orbit line (Starting on the left view profile)
    moon.location = (-orbit_radius, 0.0, 0.0)

    # Material Assignation
    m_mat = bpy.data.materials.new(name=f"{name}_Mat")
    m_mat.use_nodes = True
    mnodes = m_mat.node_tree.nodes
    mnodes.clear()
    
    m_bsdf = mnodes.new(type='ShaderNodeBsdfPrincipled')
    m_output = mnodes.new(type='ShaderNodeOutputMaterial')
    m_bsdf.inputs['Base Color'].default_value = color
    m_bsdf.inputs['Roughness'].default_value = 0.95
    
    m_mat.node_tree.links.new(m_bsdf.outputs['BSDF'], m_output.inputs['Surface'])
    moon.data.materials.append(m_mat)

    # Setup pivot containing orbit inclination + Jupiter system tilt combined
    pivot = bpy.data.objects.new(f"{name}_Pivot", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    
    moon.parent = pivot

    # Animate Orbit (Revolution) & Tidally Locked Self-Spin over 240 frames
    pivot.rotation_mode = 'XYZ'
    pivot.rotation_euler = (JUPITER_TILT + math.radians(inclination_deg), 0, math.radians(start_angle_deg))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (JUPITER_TILT + math.radians(inclination_deg), 0, math.radians(start_angle_deg + total_rotation_deg)) 
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    moon.rotation_mode = 'XYZ'
    moon.rotation_euler = (0, 0, 0)
    moon.keyframe_insert(data_path="rotation_euler", frame=1)
    moon.rotation_euler = (0, 0, math.radians(total_rotation_deg))
    moon.keyframe_insert(data_path="rotation_euler", frame=240)


# =========================================================
# GENERATE THE 95 MOONS (DYNAMICALLY ACCURATE)
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

# 1. The 4 Massive Galilean Moons (Calculated exactly for 5 Earth Days)
galilean_moons = [
    {"name": "Io",       "radius": 0.05, "orbit": 1.4, "inc": 0.04, "speed": 1017.5, "color": (0.85, 0.8, 0.2, 1.0)}, 
    {"name": "Europa",   "radius": 0.04, "orbit": 1.9, "inc": 0.47, "speed": 506.9,  "color": (0.75, 0.73, 0.68, 1.0)}, 
    {"name": "Ganymede", "radius": 0.07, "orbit": 2.5, "inc": 0.20, "speed": 251.6,  "color": (0.55, 0.52, 0.49, 1.0)}, 
    {"name": "Callisto", "radius": 0.06, "orbit": 3.2, "inc": 0.28, "speed": 107.9,  "color": (0.4, 0.38, 0.36, 1.0)}
]

for idx, gm in enumerate(galilean_moons):
    create_accurate_moon(
        name=gm["name"],
        radius=gm["radius"],
        orbit_radius=gm["orbit"],
        inclination_deg=gm["inc"],
        total_rotation_deg=gm["speed"],
        color=gm["color"],
        start_angle_deg=idx * 90.0,
        is_spherical=True
    )

# 2. Minor Swarms (91 Irregular non-spherical asteroids)
random.seed(42)
for i in range(1, 92):
    if i <= 4: # Inner Rings
        radius = random.uniform(0.01, 0.018)
        orbit = random.uniform(1.1, 1.3)
        inc = random.uniform(0.0, 0.9)
        speed = random.uniform(1200, 1800) # Fast inner orbits
    else: # Outer chaotic groups
        radius = random.uniform(0.005, 0.012)
        orbit = random.uniform(3.8, 5.8)
        inc = random.uniform(5.0, 28.0)
        speed = random.uniform(10, 80) # Slower outer orbits
        if random.choice([True, False]): 
            speed *= -1 # Retrograde orbits

    gray_val = random.uniform(0.3, 0.55)
    color = (gray_val, gray_val * 0.95, gray_val * 0.9, 1.0)
    
    create_accurate_moon(
        name=f"MinorMoon_{i}",
        radius=radius,
        orbit_radius=orbit,
        inclination_deg=inc,
        total_rotation_deg=speed,
        color=color,
        start_angle_deg=random.uniform(0, 360),
        is_spherical=False
    )

# 3. Jupiter Self-Rotation Animation (12.09 full days passed mapped to frame 240)
jupiter.rotation_mode = 'XYZ'
jupiter.rotation_euler = (JUPITER_TILT, 0, 0)
jupiter.keyframe_insert(data_path="rotation_euler", frame=1)
jupiter.rotation_euler = (JUPITER_TILT, 0, math.radians(4352.6))
jupiter.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp


# =========================================================
# LIGHTING & CAMERA (FRONT PROFILE ANGLE UNCHANGED)
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(1.5, -11.0, 3.5))
light = bpy.context.object
light.name = "SunLight"
light.rotation_euler = (math.radians(73), 0, math.radians(-10))
light.data.energy = 7.0
light.data.color = (1.0, 0.98, 0.95)

try:
    light.data.shadow_soft_size = 0.05
    light.data.use_contact_shadow = True
    light.data.contact_shadow_thickness = 0.1
except AttributeError:
    pass

bpy.ops.object.light_add(type='SUN', location=(-1.5, 11.0, -3.5))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.data.energy = 0.4
fill_light.data.color = (0.7, 0.85, 1.0)
fill_light.data.use_shadow = False

bpy.ops.object.camera_add(location=(0, -11.0, 1.5))
camera = bpy.context.object
camera.rotation_euler = (math.radians(83), 0, 0) 
camera.data.lens = 32
camera.data.clip_end = 1000
scene.camera = camera

# =========================================================
# 🌌 STAR BACKGROUND
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg        = nodes.new(type='ShaderNodeBackground')
output    = nodes.new(type='ShaderNodeOutputWorld')
noise     = nodes.new(type='ShaderNodeTexNoise')
ramp      = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value     = 500.0
noise.inputs['Detail'].default_value    = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation         = 'CONSTANT'
ramp.color_ramp.elements[0].position  = 0.0
ramp.color_ramp.elements[0].color     = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position  = 0.65
ramp.color_ramp.elements[1].color     = (1, 1, 1, 1)

math_mult.operation          = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'],       ramp.inputs['Fac'])
links.new(ramp.outputs['Color'],      math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'],   output.inputs['Surface'])

# =========================================================
# TAURUS CONSTELLATION
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location     = (4.5, 20, 3.5)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0,  1.77),
    "mid_long_1":     (-0.22, 0.0,  0.46),
    "bend":           ( 0.0,  0.0,  0.0 ),
    "tip_left_short": (-2.47, 0.0,  0.72),
    "mid_short_1":    (-0.52, 0.0,  0.08),
    "spine_1":        ( 0.65, 0.0, -0.40),
    "horn_join":      ( 1.75, 0.0, -0.67),
    "horn_join2":     ( 1.97, 0.0, -0.78),
    "horn_tip_1":     ( 0.59, 0.0, -1.25),
    "horn_tip_2":     ( 1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long",  "mid_long_1"),
    ("mid_long_1",     "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1",    "bend"),
    ("bend",           "spine_1"),
    ("spine_1",        "horn_join"),
    ("horn_join",      "horn_join2"),
    ("horn_join",      "horn_tip_1"),
    ("horn_join2",     "horn_tip_2"),
]

star_scale_factor = 0.75

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value    = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.12 if star_name == "bend" else 0.08
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value    = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a = star_objects[star_a]
    obj_b = star_objects[star_b]
    loc_a = obj_a.location.copy()
    loc_b = obj_b.location.copy()
    midpoint  = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    length    = direction.length

    bpy.ops.mesh.primitive_cylinder_add(radius=0.015, depth=length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()

# Output Settings
scene.render.filepath = "c:/textures/jupiter_95moons_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Done! Timeline extended smoothly to 10 seconds tracking 5 Earth days.")