import bpy
import math

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# =========================================================
# FPS & DURATION (EXACTLY 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 sec = 240 frames
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# =========================================================
# CONSTANTS & ORBITAL PHYSICS (5 SOLS)
# =========================================================
MARS_TILT = math.radians(25.19)  # True Axial Tilt

# 5 Sols / 0.3189 Period = 15.6788 orbits (15.6788 * 360 = 5644.4 degrees)
PHOBOS_ROT_TOTAL = math.radians(5644.4)

# 5 Sols / 1.2624 Period = 3.9607 orbits (3.9607 * 360 = 1425.85 degrees)
DEIMOS_ROT_TOTAL = math.radians(1425.85)

# =========================================================
# CREATE MARS
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1)
mars = bpy.context.object
mars.name = "Mars"
bpy.ops.object.shade_smooth()

# Fine-grained displacement modifier for realistic terrain
disp_tex = bpy.data.textures.new("MarsTerrainTex", type='CLOUDS')
disp_tex.noise_scale = 0.12  
disp_tex.noise_depth = 4

disp_mod = mars.modifiers.new(name="TerrainSurface", type='DISPLACE')
disp_mod.texture = disp_tex
disp_mod.strength = 0.025    
disp_mod.mid_level = 0.5

subsurf = mars.modifiers.new(name="Subdivide", type='SUBSURF')
subsurf.levels = 2
subsurf.render_levels = 2
mars.modifiers.move(mars.modifiers.find("Subdivide"), 0)

# Mars Material Setup
mat = bpy.data.materials.new(name="MarsMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

tex = nodes.new(type='ShaderNodeTexImage')
bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
output = nodes.new(type='ShaderNodeOutputMaterial')

try:
    tex.image = bpy.data.images.load("C:/textures/mars_color.jpg") 
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: mars_color.jpg not found, using fallback color instead.")
    bsdf.inputs['Base Color'].default_value = (0.65, 0.35, 0.2, 1.0) 

bsdf.inputs['Roughness'].default_value = 0.85
links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
mars.data.materials.append(mat)


# =========================================================
# MOON MATERIAL GENERATOR
# =========================================================
def create_moon_material(name, fallback_color):
    m_mat = bpy.data.materials.new(name=name)
    m_mat.use_nodes = True
    mnodes = m_mat.node_tree.nodes
    mlinks = m_mat.node_tree.links
    mnodes.clear()

    m_tex = mnodes.new(type='ShaderNodeTexImage')
    m_bsdf = mnodes.new(type='ShaderNodeBsdfPrincipled')
    m_output = mnodes.new(type='ShaderNodeOutputMaterial')

    try:
        m_tex.image = bpy.data.images.load("C:/textures/moon.jpg")
        mlinks.new(m_tex.outputs['Color'], m_bsdf.inputs['Base Color'])
    except RuntimeError:
        m_bsdf.inputs['Base Color'].default_value = fallback_color

    m_bsdf.inputs['Roughness'].default_value = 0.98
    if 'Specular IOR Level' in m_bsdf.inputs:
        m_bsdf.inputs['Specular IOR Level'].default_value = 0.01
    mlinks.new(m_bsdf.outputs['BSDF'], m_output.inputs['Surface'])
    return m_mat


# =========================================================
# MOONS SCALE & DISTANCE PROPORTIONS (10x Visual Multiplier)
# =========================================================
PHOBOS_RADIUS = 0.033
DEIMOS_RADIUS = 0.018

PHOBOS_ORBIT  = 1.65
DEIMOS_ORBIT  = 3.10

# --- MOON 1: PHOBOS (Starts on the Left) ---
bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=PHOBOS_RADIUS)
phobos = bpy.context.object
phobos.name = "Phobos"
bpy.ops.object.shade_smooth()
phobos.location = (-PHOBOS_ORBIT, 0.0, 0.0)

p_disp_tex = bpy.data.textures.new("PhobosTex", type='CLOUDS')
p_disp_tex.noise_scale = 0.05
p_disp_mod = phobos.modifiers.new(name="PhobosRoughness", type='DISPLACE')
p_disp_mod.texture = p_disp_tex
p_disp_mod.strength = 0.008

phobos_mat = create_moon_material("PhobosMaterial", (0.42, 0.38, 0.36, 1.0))
phobos.data.materials.append(phobos_mat)

phobos_pivot = bpy.data.objects.new("PhobosPivot", None)
bpy.context.collection.objects.link(phobos_pivot)
phobos_pivot.location = (0, 0, 0)
phobos.parent = phobos_pivot

# --- MOON 2: DEIMOS (Starts on the Left) ---
bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=DEIMOS_RADIUS)
deimos = bpy.context.object
deimos.name = "Deimos"
bpy.ops.object.shade_smooth()
deimos.location = (-DEIMOS_ORBIT, 0.0, 0.0)

d_disp_tex = bpy.data.textures.new("DeimosTex", type='CLOUDS')
d_disp_tex.noise_scale = 0.08
d_disp_mod = deimos.modifiers.new(name="DeimosRoughness", type='DISPLACE')
d_disp_mod.texture = d_disp_tex
d_disp_mod.strength = 0.003

deimos_mat = create_moon_material("DeimosMaterial", (0.52, 0.49, 0.46, 1.0))
deimos.data.materials.append(deimos_mat)

deimos_pivot = bpy.data.objects.new("DeimosPivot", None)
bpy.context.collection.objects.link(deimos_pivot)
deimos_pivot.location = (0, 0, 0)
deimos.parent = deimos_pivot


# =========================================================
# MATHEMATICALLY ACCURATE ANIMATION WITH EXPLICIT AXIAL TILT
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

# 1. MARS ROTATION: Tilted 25.19 degrees on X-axis, spins 5 full days on local Z-axis
mars.rotation_mode = 'XYZ'
mars.rotation_euler = (MARS_TILT, 0, 0)
mars.keyframe_insert(data_path="rotation_euler", frame=1)
mars.rotation_euler = (MARS_TILT, 0, math.radians(1800))
mars.keyframe_insert(data_path="rotation_euler", frame=240)

# 2. PHOBOS MOVEMENT: Orbit plane tilted on X, rotates around Z
phobos_pivot.rotation_mode = 'XYZ'
phobos_pivot.rotation_euler = (MARS_TILT, 0, 0)
phobos_pivot.keyframe_insert(data_path="rotation_euler", frame=1)
phobos_pivot.rotation_euler = (MARS_TILT, 0, PHOBOS_ROT_TOTAL)
phobos_pivot.keyframe_insert(data_path="rotation_euler", frame=240)

# Tidally Locked Self-Rotation (inherits parent plane tilt)
phobos.rotation_mode = 'XYZ'
phobos.rotation_euler = (0, 0, 0)
phobos.keyframe_insert(data_path="rotation_euler", frame=1)
phobos.rotation_euler = (0, 0, PHOBOS_ROT_TOTAL)
phobos.keyframe_insert(data_path="rotation_euler", frame=240)

# 3. DEIMOS MOVEMENT: Orbit plane tilted on X, rotates around Z
deimos_pivot.rotation_mode = 'XYZ'
deimos_pivot.rotation_euler = (MARS_TILT, 0, 0)
deimos_pivot.keyframe_insert(data_path="rotation_euler", frame=1)
deimos_pivot.rotation_euler = (MARS_TILT, 0, DEIMOS_ROT_TOTAL)
deimos_pivot.keyframe_insert(data_path="rotation_euler", frame=240)

# Tidally Locked Self-Rotation (inherits parent plane tilt)
deimos.rotation_mode = 'XYZ'
deimos.rotation_euler = (0, 0, 0)
deimos.keyframe_insert(data_path="rotation_euler", frame=1)
deimos.rotation_euler = (0, 0, DEIMOS_ROT_TOTAL)
deimos.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp


# =========================================================
# LIGHT (Upper-Left-Front)
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(-8.0, -6.0, 7.0))
light = bpy.context.object
light.name = "SunLight"

light.rotation_euler = (math.radians(50), math.radians(25), math.radians(-50))
light.data.energy = 6.5
light.data.color = (1.0, 0.98, 0.95)

try:
    light.data.shadow_soft_size = 0.05
    light.data.use_contact_shadow = True
    light.data.contact_shadow_thickness = 0.1
except AttributeError:
    pass

# Ambient lower-right-back fill light
bpy.ops.object.light_add(type='SUN', location=(8.0, 6.0, -4.0))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.rotation_euler = (math.radians(-130), math.radians(-25), math.radians(130))
fill_light.data.energy = 0.35
fill_light.data.color = (0.7, 0.85, 1.0)
fill_light.data.use_shadow = False

# =========================================================
# CAMERA (Slightly further away to fit the vast system)
# =========================================================
bpy.ops.object.camera_add(location=(0, -10.0, 0))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35
camera.data.clip_end = 500
scene.camera = camera

try:
    scene.eevee.use_bloom = True
    scene.eevee.bloom_intensity = 0.15
except AttributeError:
    pass



# =========================================================
# 🌌 STAR BACKGROUND
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.65
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.66
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 10.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])


# =========================================================
# TAURUS CONSTELLATION
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location = (4.5, 14, 3.5)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0,  1.77),
    "mid_long_1":     (-0.22, 0.0,  0.46),
    "bend":           ( 0.0,  0.0,  0.0 ),
    "tip_left_short": (-2.47, 0.0,  0.72),
    "mid_short_1":    (-0.52, 0.0,  0.08),
    "spine_1":        ( 0.65, 0.0, -0.40),
    "horn_join":      ( 1.75, 0.0, -0.67),
    "horn_join2":     ( 1.97, 0.0, -0.78),
    "horn_tip_1":     ( 0.59, 0.0, -1.25),
    "horn_tip_2":     ( 1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long",  "mid_long_1"),
    ("mid_long_1",     "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1",    "bend"),
    ("bend",           "spine_1"),
    ("spine_1",        "horn_join"),
    ("horn_join",      "horn_join2"),
    ("horn_join",      "horn_tip_1"),
    ("horn_join2",     "horn_tip_2"),
]

star_scale_factor = 0.55

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.09 if star_name == "bend" else 0.06
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a = star_objects[star_a]
    obj_b = star_objects[star_b]
    loc_a = obj_a.location.copy()
    loc_b = obj_b.location.copy()
    midpoint  = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    length    = direction.length

    bpy.ops.mesh.primitive_cylinder_add(radius=0.012, depth=length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()

scene.render.filepath = "c:/textures/mars_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Done! Core tilt baked directly into meshes. Camera angle perfectly level.")