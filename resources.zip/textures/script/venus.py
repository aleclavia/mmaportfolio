import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# =========================================================
# FPS & DURATION (5 EARTH DAYS COMPRESSED TO 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 sec = 240 frames
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Astronomy Constants
VENUS_TILT = math.radians(177.3)  # Retrograde physical axial tilt inversion
# 5 days / 243.02 days total rotation * 360 degrees = 7.41 degrees (Retrograde / Negative)
VENUS_ROTATION_5Sols = math.radians(-7.41) 

# =========================================================
# CREATE VENUS (SMOOTH CLOUD SHROUD)
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1)
venus = bpy.context.object
venus.name = "Venus"
bpy.ops.object.shade_smooth()

# Material with Calibrated Cloud Roughness
mat = bpy.data.materials.new(name="VenusMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

tex = nodes.new(type='ShaderNodeTexImage')
bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
output = nodes.new(type='ShaderNodeOutputMaterial')

try:
    tex.image = bpy.data.images.load("C:/textures/venus_color.jpg")
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: venus_color.jpg not found, using fallback color instead.")
    bsdf.inputs['Base Color'].default_value = (0.85, 0.65, 0.45, 1.0) 

# 0.45 simulates the high-albedo scattering of dense sulfuric acid cloud decks
bsdf.inputs['Roughness'].default_value = 0.45

links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
venus.data.materials.append(mat)


# =========================================================
# LINEAR VENUS ANIMATION (RETROGRADE SPIN OVER 240 FRAMES)
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

venus.rotation_mode = 'XYZ'
venus.rotation_euler = (VENUS_TILT, 0, 0)
venus.keyframe_insert(data_path="rotation_euler", frame=1)
venus.rotation_euler = (VENUS_TILT, 0, VENUS_ROTATION_5Sols)
venus.keyframe_insert(data_path="rotation_euler", frame=240)


# =========================================================
# STABLE ASTEROID BELT / ORBITS (WITH ASTEROID.JPG)
# =========================================================
asteroid_mat = bpy.data.materials.new(name="AsteroidMaterial")
asteroid_mat.use_nodes = True
a_nodes = asteroid_mat.node_tree.nodes
a_links = asteroid_mat.node_tree.links
a_nodes.clear()

a_tex_coord = a_nodes.new(type='ShaderNodeTexCoord')
a_tex = a_nodes.new(type='ShaderNodeTexImage')
absdf = a_nodes.new(type='ShaderNodeBsdfPrincipled')
a_output = a_nodes.new(type='ShaderNodeOutputMaterial')

try:
    a_tex.image = bpy.data.images.load("C:/textures/asteroid.jpg")
    a_links.new(a_tex_coord.outputs['Generated'], a_tex.inputs['Vector'])
    a_links.new(a_tex.outputs['Color'], absdf.inputs['Base Color'])
except RuntimeError:
    print("WARNING: asteroid.jpg not found, using fallback rock color.")
    absdf.inputs['Base Color'].default_value = (0.25, 0.22, 0.2, 1.0)

# Porous space rock aggregates scatter light evenly (Matte)
absdf.inputs['Roughness'].default_value = 1.0
a_links.new(absdf.outputs['BSDF'], a_output.inputs['Surface'])

num_asteroids = 12
random.seed(42)

for i in range(num_asteroids):
    size = random.uniform(0.04, 0.12)
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=size)
    asteroid = bpy.context.object
    asteroid.name = f"StableAsteroid_{i+1}"
    bpy.ops.object.shade_flat()

    a_disp_tex = bpy.data.textures.new(f"AsteroidTex_{i+1}", type='CLOUDS')
    a_disp_tex.noise_scale = 0.4
    a_disp_mod = asteroid.modifiers.new(name="RoughRock", type='DISPLACE')
    a_disp_mod.texture = a_disp_tex
    a_disp_mod.strength = 0.22
    asteroid.data.materials.append(asteroid_mat)

    # Orbital space safely outside Venus's mesh profile
    orbit_radius = random.uniform(1.4, 3.2)
    asteroid.location = (-orbit_radius, 0.0, 0.0)

    # Local Pivot Ring system centered around Venus
    pivot = bpy.data.objects.new(f"AsteroidPivot_{i+1}", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    asteroid.parent = pivot

    start_angle = random.uniform(0, 360)
    orbit_speed = random.uniform(240, 720) 
    if random.choice([True, False]):
        orbit_speed *= -1 
    
    # Orbit planes aligned relative to Venus's spatial tilt
    local_inc = VENUS_TILT + math.radians(random.uniform(-8.0, 8.0))

    # Animate Orbit (Revolution)
    pivot.rotation_mode = 'XYZ'
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle + orbit_speed))
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    # Animate Tumbling (Self-Spin)
    asteroid.rotation_mode = 'XYZ'
    asteroid.rotation_euler = (0, 0, 0)
    asteroid.keyframe_insert(data_path="rotation_euler", frame=1)
    asteroid.rotation_euler = (random.uniform(5, 12), random.uniform(5, 12), random.uniform(5, 12))
    asteroid.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp


# =========================================================
# LIGHTING & CAMERA (FLAT ANGLE PROFILE MAINTAINED)
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(5, 5, 5))
light = bpy.context.object
light.data.energy = 4

bpy.ops.object.camera_add(location=(0, -6.5, 0)) 
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35
camera.data.clip_end = 500
scene.camera = camera

try:
    scene.eevee.use_bloom = True
    scene.eevee.bloom_intensity = 0.15
except AttributeError:
    pass


# =========================================================
# 🌌 STAR BACKGROUND
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg = nodes.new(type='ShaderNodeBackground')
output = nodes.new(type='ShaderNodeOutputWorld')
noise = nodes.new(type='ShaderNodeTexNoise')
ramp = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value = 500.0
noise.inputs['Detail'].default_value = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation = 'CONSTANT'
ramp.color_ramp.elements[0].position = 0.0
ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position = 0.62      
ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

math_mult.operation = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
links.new(ramp.outputs['Color'], math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'], output.inputs['Surface'])


# =========================================================
# TAURUS CONSTELLATION
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location = (4.5, 14, 3.5)  
constellation_anchor.rotation_euler = (0, 0, 0)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0, 1.77),
    "mid_long_1":     (-0.22, 0.0, 0.46),
    "bend":           (0.0, 0.0, 0.0),     
    "tip_left_short": (-2.47, 0.0, 0.72),
    "mid_short_1":    (-0.52, 0.0, 0.08),
    "spine_1":        (0.65, 0.0, -0.40),
    "horn_join":      (1.75, 0.0, -0.67),
    "horn_join2":     (1.97, 0.0, -0.78),
    "horn_tip_1":     (0.59, 0.0, -1.25),
    "horn_tip_2":     (1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long", "mid_long_1"),
    ("mid_long_1", "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1", "bend"),
    ("bend", "spine_1"),
    ("spine_1", "horn_join"),
    ("horn_join", "horn_join2"),
    ("horn_join", "horn_tip_1"),
    ("horn_join2", "horn_tip_2"),
]

star_scale_factor = 0.55

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.09 if star_name == "bend" else 0.06
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)

    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value = (1.0, 0.95, 0.3, 1.0)  
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a = star_objects[star_a]
    obj_b = star_objects[star_b]
    loc_a = obj_a.location.copy()
    loc_b = obj_b.location.copy()
    midpoint = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    length = direction.length

    bpy.ops.mesh.primitive_cylinder_add(radius=0.012, depth=length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    rot_quat = direction.to_track_quat('Z', 'X')
    line_obj.rotation_euler = rot_quat.to_euler()

# Output Settings
scene.render.filepath = "c:/textures/venus_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Done! Venus script successfully expanded into a stable 10-second orbital simulation.")