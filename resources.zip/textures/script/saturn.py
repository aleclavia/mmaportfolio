import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE CONFIGURATION (BLENDER 5.1 TARGETED)
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT' if hasattr(bpy.types, "RenderEeveeNextSettings") else 'BLENDER_EEVEE'

# Explicitly guarantee compositing pipeline is off to eliminate black frame results
scene.render.use_compositing = False

# =========================================================
# TIMELINE DURATION (EXACTLY 10 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 240   # 24 fps * 10 sec = 240 frames
scene.render.fps = 24

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# Exact Space Physics Metrics
SATURN_TILT = math.radians(26.73)
# 10.5 Hour rotation period translates to ~11.428 full spins over a 5 earth day time-lapse
SATURN_5_DAY_ROTATION = math.radians(4114.28)

# =========================================================
# CREATE SATURN SYSTEM BASIS
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1.0)
saturn = bpy.context.object
saturn.name = "Saturn"
bpy.ops.object.shade_smooth()

# Flat Ring Disc Geometry Setup
bpy.ops.mesh.primitive_circle_add(vertices=512, radius=2.5, fill_type='NGON')
saturn_ring = bpy.context.object
saturn_ring.name = "Saturn_Ring"
saturn_ring.parent = saturn

saturn_ring.scale[2] = 0.001
saturn_ring.location.z = 0.005

# Apply Global System Tilt Directly to the Planet Core Frame
saturn.rotation_mode = 'XYZ'
saturn.rotation_euler = (SATURN_TILT, 0, 0)

# =========================================================
# MATERIAL 1: PLANET BODY
# =========================================================
mat_body = bpy.data.materials.new(name="SaturnBodyMaterial")
mat_body.use_nodes = True
nodes_b = mat_body.node_tree.nodes
links_b = mat_body.node_tree.links
nodes_b.clear()

tex_b = nodes_b.new(type='ShaderNodeTexImage')
bsdf_b = nodes_b.new(type='ShaderNodeBsdfPrincipled')
output_b = nodes_b.new(type='ShaderNodeOutputMaterial')

try:
    tex_b.image = bpy.data.images.load("C:/textures/saturn_color.jpg")
    links_b.new(tex_b.outputs['Color'], bsdf_b.inputs['Base Color'])
except RuntimeError:
    print("WARNING: saturn_color.jpg not found, falling back onto procedural baseline.")
    bsdf_b.inputs['Base Color'].default_value = (0.84, 0.76, 0.61, 1.0)

bsdf_b.inputs['Roughness'].default_value = 0.50
links_b.new(bsdf_b.outputs['BSDF'], output_b.inputs['Surface'])
saturn.data.materials.append(mat_body)

# =========================================================
# MATERIAL 2: PROPORTIONAL RADIAL RINGS
# =========================================================
mat_ring = bpy.data.materials.new(name="SaturnRingMaterial")
mat_ring.use_nodes = True
mat_ring.blend_method = 'BLEND'

nodes_r = mat_ring.node_tree.nodes
links_r = mat_ring.node_tree.links
nodes_r.clear()

tex_coord = nodes_r.new("ShaderNodeTexCoord")
vec_math = nodes_r.new("ShaderNodeVectorMath")
math_map = nodes_r.new("ShaderNodeMapRange")
combine = nodes_r.new("ShaderNodeCombineXYZ")
tex_r = nodes_r.new("ShaderNodeTexImage")
bsdf_r = nodes_r.new("ShaderNodeBsdfPrincipled")
output_r = nodes_r.new("ShaderNodeOutputMaterial")

vec_math.operation = 'DISTANCE'

math_map.inputs['From Min'].default_value = 1.3  
math_map.inputs['From Max'].default_value = 2.5  
math_map.inputs['To Min'].default_value = 0.0
math_map.inputs['To Max'].default_value = 1.0

try:
    tex_r.image = bpy.data.images.load("C:/textures/saturn_ring.png")
except RuntimeError:
    print("WARNING: saturn_ring.png not mapped successfully.")

links_r.new(tex_coord.outputs['Object'], vec_math.inputs[0])
links_r.new(vec_math.outputs['Value'], math_map.inputs['Value'])
links_r.new(math_map.outputs['Result'], combine.inputs['X'])
links_r.new(combine.outputs['Vector'], tex_r.inputs['Vector'])

bsdf_r.inputs['Roughness'].default_value = 0.75
links_r.new(tex_r.outputs['Color'], bsdf_r.inputs['Base Color'])
links_r.new(tex_r.outputs['Alpha'], bsdf_r.inputs['Alpha'])  
links_r.new(bsdf_r.outputs['BSDF'], output_r.inputs['Surface'])

saturn_ring.data.materials.append(mat_ring)

# =========================================================
# MOON CREATION PIPELINE
# =========================================================
def create_saturn_moon(name, radius, orbit_radius, inclination_deg, total_rotation_deg, color, start_angle_deg):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=radius)
    moon = bpy.context.object
    moon.name = name
    bpy.ops.object.shade_smooth()
    
    moon.location = (orbit_radius, 0.0, 0.0)

    m_mat = bpy.data.materials.new(name=f"{name}_Mat")
    m_mat.use_nodes = True
    mnodes = m_mat.node_tree.nodes
    mnodes.clear()
    
    m_bsdf = mnodes.new(type='ShaderNodeBsdfPrincipled')
    m_output = mnodes.new(type='ShaderNodeOutputMaterial')
    m_bsdf.inputs['Base Color'].default_value = color
    m_bsdf.inputs['Roughness'].default_value = 0.85
    
    m_mat.node_tree.links.new(m_bsdf.outputs['BSDF'], m_output.inputs['Surface'])
    moon.data.materials.append(m_mat)

    # Establish Pivot Frame
    pivot = bpy.data.objects.new(f"{name}_Pivot", None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = (0, 0, 0)
    moon.parent = pivot

    # Revolution Calculations (Orbits aligned to the Ring/Equatorial Frame)
    local_inc = SATURN_TILT + math.radians(inclination_deg)
    
    animated_speed = total_rotation_deg * 2.0

    pivot.rotation_mode = 'ZXY'
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle_deg))
    pivot.keyframe_insert(data_path="rotation_euler", frame=1)
    pivot.rotation_euler = (local_inc, 0, math.radians(start_angle_deg + animated_speed)) 
    pivot.keyframe_insert(data_path="rotation_euler", frame=240)

    # Axial Moon Spin Properties
    moon.rotation_mode = 'XYZ'
    moon.rotation_euler = (0, 0, 0)
    moon.keyframe_insert(data_path="rotation_euler", frame=1)
    moon.rotation_euler = (0, 0, math.radians(animated_speed * 1.05))
    moon.keyframe_insert(data_path="rotation_euler", frame=240)

# =========================================================
# GENERATE PRIMARY MOONS (COMPACT ORBIT DISTANCES)
# =========================================================
global_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

# Scaled orbits inward so they sit tightly grouped outside the main ring footprint
major_moons = [
    {"name": "Mimas",     "radius": 0.08, "orbit": 1.45, "inc": 1.5,  "speed": 620, "color": (0.55, 0.55, 0.55, 1.0)}, 
    {"name": "Enceladus", "radius": 0.09, "orbit": 1.70, "inc": 0.0,  "speed": 510, "color": (0.90, 0.92, 0.95, 1.0)}, 
    {"name": "Tethys",    "radius": 0.11, "orbit": 1.95, "inc": 1.1,  "speed": 420, "color": (0.70, 0.70, 0.72, 1.0)}, 
    {"name": "Dione",     "radius": 0.12, "orbit": 2.25, "inc": 0.0,  "speed": 340, "color": (0.60, 0.61, 0.63, 1.0)}, 
    {"name": "Rhea",      "radius": 0.14, "orbit": 2.60, "inc": 0.3,  "speed": 260, "color": (0.65, 0.65, 0.65, 1.0)}, 
    {"name": "Titan",     "radius": 0.24, "orbit": 2.95, "inc": 0.3,  "speed": 180, "color": (0.85, 0.65, 0.25, 1.0)}, 
    {"name": "Hyperion",  "radius": 0.07, "orbit": 3.25, "inc": 0.5,  "speed": 140, "color": (0.50, 0.45, 0.38, 1.0)}, 
    {"name": "Iapetus",   "radius": 0.13, "orbit": 3.55, "inc": 15.4, "speed": 90,  "color": (0.35, 0.32, 0.30, 1.0)}, 
    {"name": "Phoebe",    "radius": 0.06, "orbit": 3.85, "inc": 173.0,"speed": -45, "color": (0.25, 0.25, 0.25, 1.0)}  
]

for idx, mm in enumerate(major_moons):
    create_saturn_moon(
        name=mm["name"],
        radius=mm["radius"],
        orbit_radius=mm["orbit"],
        inclination_deg=mm["inc"],
        total_rotation_deg=mm["speed"],
        color=mm["color"],
        start_angle_deg=idx * 40.0
    )

# Procedural System Populations (Moons 10 to 125)
random.seed(275)
for i in range(10, 126):
    if i <= 25:
        # Ring-skimming minor bodies nestled tightly into inner system gaps
        radius = random.uniform(0.03, 0.05)
        orbit = random.uniform(1.10, 1.35) 
        inc = random.uniform(0.0, 0.5)
        speed = random.uniform(700, 950)
    else:
        # Outlying minor clusters compressed significantly inward to remove scattering
        radius = random.uniform(0.02, 0.04)
        orbit = random.uniform(4.20, 6.00)
        inc = random.uniform(15.0, 48.0) if random.choice([True, False]) else random.uniform(130.0, 175.0) 
        speed = random.uniform(20, 75)
        if inc > 90.0:
            speed *= -1

    gray_tone = random.uniform(0.3, 0.55)
    color = (gray_tone, gray_tone * 0.98, gray_tone * 0.95, 1.0)
    
    create_saturn_moon(
        name=f"SaturnMoon_{i}",
        radius=radius,
        orbit_radius=orbit,
        inclination_deg=inc,
        total_rotation_deg=speed,
        color=color,
        start_angle_deg=random.uniform(0, 360)
    )

# =========================================================
# SATURN PLANET BODY ANIMATION
# =========================================================
saturn.rotation_euler = (SATURN_TILT, 0, 0)
saturn.keyframe_insert(data_path="rotation_euler", frame=1)
saturn.rotation_euler = (SATURN_TILT, 0, SATURN_5_DAY_ROTATION)
saturn.keyframe_insert(data_path="rotation_euler", frame=240)

bpy.context.preferences.edit.keyframe_new_interpolation_type = global_prev_interp

# =========================================================
# LIGHTING INFRASTRUCTURE
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(-12.0, -2.0, 2.0))
light = bpy.context.object
light.name = "SunLight"
light.rotation_euler = (math.radians(80), 0, math.radians(-85))
light.data.energy = 7.5
light.data.color = (1.0, 0.98, 0.95)

# Secondary ambient fill 
bpy.ops.object.light_add(type='SUN', location=(12.0, 2.0, -2.0))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.data.energy = 0.4
fill_light.data.color = (0.7, 0.82, 1.0)
fill_light.data.use_shadow = False

# =========================================================
# CAMERA (PULLED IN FOR A MUCH CLOSER, COMPACT LOOK)
# =========================================================
bpy.ops.object.camera_add(location=(0, -16.0, 2))
camera = bpy.context.object
camera.rotation_euler = (math.radians(81), 0, 0) 
camera.data.lens = 30
camera.data.clip_end = 1500
scene.camera = camera

# ----------------------------
# 🌌 STAR BACKGROUND
# ----------------------------
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg        = nodes.new(type='ShaderNodeBackground')
output    = nodes.new(type='ShaderNodeOutputWorld')
noise     = nodes.new(type='ShaderNodeTexNoise')
ramp      = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value     = 500.0
noise.inputs['Detail'].default_value    = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation         = 'CONSTANT'
ramp.color_ramp.elements[0].position  = 0.0
ramp.color_ramp.elements[0].color     = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position  = 0.65
ramp.color_ramp.elements[1].color     = (1, 1, 1, 1)

math_mult.operation          = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'],       ramp.inputs['Fac'])
links.new(ramp.outputs['Color'],      math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'],   output.inputs['Surface'])

# =========================================================
# TAURUS CONSTELLATION
# =========================================================
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location     = (4.5, 25, 3.5)
constellation_anchor.rotation_euler = (0, 0, 0)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0,  1.77),
    "mid_long_1":     (-0.22, 0.0,  0.46),
    "bend":           ( 0.0,  0.0,  0.0 ),
    "tip_left_short": (-2.47, 0.0,  0.72),
    "mid_short_1":    (-0.52, 0.0,  0.08),
    "spine_1":        ( 0.65, 0.0, -0.40),
    "horn_join":      ( 1.75, 0.0, -0.67),
    "horn_join2":     ( 1.97, 0.0, -0.78),
    "horn_tip_1":     ( 0.59, 0.0, -1.25),
    "horn_tip_2":     ( 1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long",  "mid_long_1"),
    ("mid_long_1",     "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1",    "bend"),
    ("bend",           "spine_1"),
    ("spine_1",        "horn_join"),
    ("horn_join",      "horn_join2"),
    ("horn_join",      "horn_tip_1"),
    ("horn_join2",     "horn_tip_2"),
]

star_scale_factor = 0.95

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value    = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.14 if star_name == "bend" else 0.09
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value    = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a, obj_b = star_objects[star_a], star_objects[star_b]
    loc_a, loc_b = obj_a.location.copy(), obj_b.location.copy()
    midpoint  = (loc_a + loc_b) / 2
    direction = loc_b - loc_a

    bpy.ops.mesh.primitive_cylinder_add(radius=0.015, depth=direction.length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()

# =========================================================
# OUTPUT FILE CONFIGURATIONS
# =========================================================
scene.render.filepath = "c:/textures/saturn_moons_system_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Success! System compressed for a beautiful, nested profile.")