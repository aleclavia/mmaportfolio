import bpy
import math
import random

# =========================================================
# RESET SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Clean up orphan data from previous runs (materials, meshes, etc.)
for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

# =========================================================
# RENDER ENGINE (FAST)
# =========================================================
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
scene.eevee.taa_render_samples = 16
scene.eevee.taa_samples = 16

# =========================================================
# FPS & DURATION (EXACTLY 5 SECONDS)
# =========================================================
scene.frame_start = 1
scene.frame_end = 120   # 24 fps * 5 sec
scene.render.fps = 24

# =========================================================
# RESOLUTION (16:9)
# =========================================================
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

# =========================================================
# CREATE THE SUN (MASSIVE, TURBULENT PLASMA BALL)
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(segments=64, ring_count=32, radius=1.5)
sun = bpy.context.object
sun.name = "Sun"

bpy.ops.object.shade_smooth()

# High-intensity displacement to simulate solar mass turbulence and plasma arcs
sun_disp_tex = bpy.data.textures.new("SunPlasmaTex", type='CLOUDS')
sun_disp_tex.noise_scale = 0.25

sun_disp_mod = sun.modifiers.new(name="PlasmaTurbulence", type='DISPLACE')
sun_disp_mod.texture = sun_disp_tex
sun_disp_mod.strength = 0.045  # Noticeable craggy, boiling surface deformation
sun_disp_mod.mid_level = 0.5

# Ensure smooth, non-faceted topology under heavy deformation
sun_subsurf = sun.modifiers.new(name="Subdivide", type='SUBSURF')
sun_subsurf.levels = 2
sun_subsurf.render_levels = 2
sun.modifiers.move(sun.modifiers.find("Subdivide"), 0)

# =========================================================
# SUN TEXTURED EMISSION MATERIAL
# =========================================================
sun_mat = bpy.data.materials.new(name="SunMaterial")
sun_mat.use_nodes = True
sun_nodes = sun_mat.node_tree.nodes
sun_links = sun_mat.node_tree.links
sun_nodes.clear()

# Create nodes: Texture -> Emission -> Output
sun_tex = sun_nodes.new(type='ShaderNodeTexImage')
sun_emission = sun_nodes.new(type='ShaderNodeEmission')
sun_output = sun_nodes.new(type='ShaderNodeOutputMaterial')

try:
    # Load your custom sun texture map
    sun_tex.image = bpy.data.images.load("C:/textures/sun.jpg")
    sun_links.new(sun_tex.outputs['Color'], sun_emission.inputs['Color'])
except RuntimeError:
    print("WARNING: sun.jpg not found, using fallback solar color profile.")
    # Fallback fiery solar color if image is missing
    sun_emission.inputs['Color'].default_value = (1.0, 0.45, 0.08, 1.0)

# Drive the emission strength high so the texture maps brightly into EEVEE's Bloom
sun_emission.inputs['Strength'].default_value = 4.0

sun_links.new(sun_emission.outputs['Emission'], sun_output.inputs['Surface'])
sun.data.materials.append(sun_mat)

# =========================================================
# SUN ANIMATION (SOLAR ROTATION)
# =========================================================
_prev_interp = bpy.context.preferences.edit.keyframe_new_interpolation_type
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'

# Linear continuous rotation sweep across the 5-second timeframe
sun.rotation_euler = (0, 0, 0)
sun.keyframe_insert(data_path="rotation_euler", frame=1)
sun.rotation_euler = (0, 0, math.radians(60)) # Smooth, majestic rotational speed
sun.keyframe_insert(data_path="rotation_euler", frame=120)

bpy.context.preferences.edit.keyframe_new_interpolation_type = _prev_interp

# =========================================================
# LIGHT (Upper-Left-Front)
# =========================================================
bpy.ops.object.light_add(type='SUN', location=(-8.0, -6.0, 7.0))
light = bpy.context.object
light.name = "SunLight"

light.rotation_euler = (math.radians(50), math.radians(25), math.radians(-50))
light.data.energy = 6.5
light.data.color = (1.0, 0.98, 0.95)

try:
    light.data.shadow_soft_size = 0.05
    light.data.use_contact_shadow = True
    light.data.contact_shadow_thickness = 0.1
except AttributeError:
    pass

# Ambient lower-right-back fill light
bpy.ops.object.light_add(type='SUN', location=(8.0, 6.0, -4.0))
fill_light = bpy.context.object
fill_light.name = "SpaceFillLight"
fill_light.rotation_euler = (math.radians(-130), math.radians(-25), math.radians(130))
fill_light.data.energy = 0.35
fill_light.data.color = (0.7, 0.85, 1.0)
fill_light.data.use_shadow = False

# =========================================================
# CAMERA (Slightly further away to fit the vast system)
# =========================================================
bpy.ops.object.camera_add(location=(0, -8.0, 0))
camera = bpy.context.object
camera.rotation_euler = (math.radians(90), 0, 0)
camera.data.lens = 35
camera.data.clip_end = 500
scene.camera = camera

try:
    scene.eevee.use_bloom = True
    scene.eevee.bloom_intensity = 0.15
except AttributeError:
    pass

# =========================================================
# STAR BACKGROUND & CONSTELLATION
# =========================================================
world = scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

bg        = nodes.new(type='ShaderNodeBackground')
output    = nodes.new(type='ShaderNodeOutputWorld')
noise     = nodes.new(type='ShaderNodeTexNoise')
ramp      = nodes.new(type='ShaderNodeValToRGB')
math_mult = nodes.new(type='ShaderNodeMath')

noise.inputs['Scale'].default_value     = 500.0
noise.inputs['Detail'].default_value    = 15.0
noise.inputs['Roughness'].default_value = 0.9

ramp.color_ramp.interpolation         = 'CONSTANT'
ramp.color_ramp.elements[0].position  = 0.0
ramp.color_ramp.elements[0].color     = (0, 0, 0, 1)
ramp.color_ramp.elements[1].position  = 0.63
ramp.color_ramp.elements[1].color     = (1, 1, 1, 1)

math_mult.operation           = 'MULTIPLY'
math_mult.inputs[1].default_value = 8.0

links.new(noise.outputs['Fac'],       ramp.inputs['Fac'])
links.new(ramp.outputs['Color'],      math_mult.inputs[0])
links.new(math_mult.outputs['Value'], bg.inputs['Color'])
links.new(bg.outputs['Background'],   output.inputs['Surface'])

# Taurus Setup
constellation_anchor = bpy.data.objects.new("TaurusAnchor", None)
bpy.context.collection.objects.link(constellation_anchor)
constellation_anchor.location     = (4.5, 14, 3.5)

taurus_stars = {
    "tip_left_long":  (-2.05, 0.0,  1.77),
    "mid_long_1":     (-0.22, 0.0,  0.46),
    "bend":           ( 0.0,  0.0,  0.0 ),
    "tip_left_short": (-2.47, 0.0,  0.72),
    "mid_short_1":    (-0.52, 0.0,  0.08),
    "spine_1":        ( 0.65, 0.0, -0.40),
    "horn_join":      ( 1.75, 0.0, -0.67),
    "horn_join2":     ( 1.97, 0.0, -0.78),
    "horn_tip_1":     ( 0.59, 0.0, -1.25),
    "horn_tip_2":     ( 1.58, 0.0, -1.96),
}

taurus_connections = [
    ("tip_left_long",  "mid_long_1"),
    ("mid_long_1",     "bend"),
    ("tip_left_short", "mid_short_1"),
    ("mid_short_1",    "bend"),
    ("bend",           "spine_1"),
    ("spine_1",        "horn_join"),
    ("horn_join",      "horn_join2"),
    ("horn_join",      "horn_tip_1"),
    ("horn_join2",     "horn_tip_2"),
]

star_scale_factor = 0.55

const_star_mat = bpy.data.materials.new(name="ConstellationStarMaterial")
const_star_mat.use_nodes = True
csnodes = const_star_mat.node_tree.nodes
csnodes.clear()
cs_emission = csnodes.new(type='ShaderNodeEmission')
cs_emission.inputs['Color'].default_value    = (1.0, 0.65, 0.15, 1.0)
cs_emission.inputs['Strength'].default_value = 10.0
cs_output = csnodes.new(type='ShaderNodeOutputMaterial')
const_star_mat.node_tree.links.new(cs_emission.outputs['Emission'], cs_output.inputs['Surface'])

star_objects = {}
for star_name, (x, y, z) in taurus_stars.items():
    radius = 0.09 if star_name == "bend" else 0.06
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=radius)
    star_obj = bpy.context.object
    star_obj.name = f"Taurus_{star_name}"
    bpy.ops.object.shade_smooth()
    star_obj.data.materials.append(const_star_mat)
    star_obj.location = (x * star_scale_factor, y * star_scale_factor, z * star_scale_factor)
    star_obj.parent = constellation_anchor
    star_objects[star_name] = star_obj

line_mat = bpy.data.materials.new(name="ConstellationLineMaterial")
line_mat.use_nodes = True
lnodes = line_mat.node_tree.nodes
lnodes.clear()
l_emission = lnodes.new(type='ShaderNodeEmission')
l_emission.inputs['Color'].default_value    = (1.0, 0.95, 0.3, 1.0)
l_emission.inputs['Strength'].default_value = 3.0
l_output = lnodes.new(type='ShaderNodeOutputMaterial')
line_mat.node_tree.links.new(l_emission.outputs['Emission'], l_output.inputs['Surface'])

for star_a, star_b in taurus_connections:
    obj_a, obj_b = star_objects[star_a], star_objects[star_b]
    loc_a, loc_b = obj_a.location.copy(), obj_b.location.copy()
    midpoint = (loc_a + loc_b) / 2
    direction = loc_b - loc_a
    
    bpy.ops.mesh.primitive_cylinder_add(radius=0.012, depth=direction.length, location=midpoint)
    line_obj = bpy.context.object
    line_obj.name = f"Line_{star_a}_{star_b}"
    line_obj.data.materials.append(line_mat)
    line_obj.parent = constellation_anchor
    line_obj.rotation_euler = direction.to_track_quat('Z', 'X').to_euler()

# =========================================================
# OUTPUT SETTINGS
# =========================================================
scene.render.filepath = "c:/textures/pluto_animation.mp4"
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'

print("Done! pluto system with all 29 moons, background starfield, and Taurus are ready.")